
def update_distance_recursive(X, Y, memo, i, j):
    # memoization
    if memo[i][j] != -1:
        return memo[i][j]
    
    # base cases
    if i == 0:
        memo[i][j] = (j, [f"insert({Y[k]},{k})" for k in range(j)])
        return memo[i][j]
    if j == 0:
        memo[i][j] = (i, [f"delete(1)" for k in range(i)])
        return memo[i][j]
    
    # calculate local optimal using sub local optimals
    if X[i-1] == Y[j-1]:
        memo[i][j] = update_distance_recursive(X, Y, memo, i-1, j-1)
    else:
        insert = update_distance_recursive(X, Y, memo, i, j-1)
        delete = update_distance_recursive(X, Y, memo, i-1, j)
        replace = update_distance_recursive(X, Y, memo, i-1, j-1)
        
        if insert[0] <= delete[0] and insert[0] <= replace[0]:
            memo[i][j] = (insert[0]+1, insert[1]+[f"insert({Y[j-1]},{j-1})"])
        elif delete[0] <= insert[0] and delete[0] <= replace[0]:
            memo[i][j] = (delete[0]+1, delete[1]+[f"delete({j+1})"])
        else:
            memo[i][j] = (replace[0]+1, replace[1]+[f"replace({j},{Y[j-1]})"])

    return memo[i][j]

def update_distance(X, Y):
    m = len(X)
    n = len(Y)
    
    memo = [[-1 for i in range(n+1)] for j in range(m+1)]
    memo[0][0] = (0, [])

    return update_distance_recursive(X, Y, memo, m, n)
