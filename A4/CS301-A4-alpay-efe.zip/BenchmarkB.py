import random
import time
import csv
from update_distance_problem import update_distance

def generate_test_case(size1, size2):
    """Generate a random test case of a given size."""
    X = [(random.randint(1, j), random.randint(j, 10)) for _ in range(size1) for j in [random.randint(1, 10)]]
    Y = [(random.randint(1, j), random.randint(j, 10)) for _ in range(size2) for j in [random.randint(1, 10)]]
    return X, Y

def measure_performance(X, Y):
    """Measure the performance of the update_distance function."""
    start_time = time.time()
    num_operations, operations = update_distance(X, Y)
    end_time = time.time()
    return end_time - start_time, num_operations, operations

def benchmark():
    sizes1 = [random.randint(1 + 10 * i, 10 + i * 10) for i in range(10)]
    sizes2 = [random.randint(1 + 10 * i, 10 + i * 10) for i in range(10)]
    num_cases_per_size = 100
    results = []

    for i in range(10):
        for _ in range(num_cases_per_size):
            X, Y = generate_test_case(sizes1[i], sizes2[i])
            time_taken, num_operations, operations = measure_performance(X, Y)
            results.append([sizes1[i], sizes2[i], X, Y, time_taken, num_operations, '; '.join(operations)])

    with open('benchmarkB_results.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['Size of X', 'Size of Y', 'X', 'Y', 'Time (seconds)', 'Update Distance', 'Operations'])
        writer.writerows(results)


if __name__ == "__main__":
    benchmark()