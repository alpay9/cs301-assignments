import unittest
from update_distance_problem import update_distance

class TestUpdateDistance(unittest.TestCase):
    # whitebox testing
    def test_X_empty_case(self):
        X = []
        Y = [(1, 1)]
        expected = (1, ['insert((1, 1),0)'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_Y_empty_case(self):
        X = [(1, 1)]
        Y = []
        expected = (1, ['delete(1)'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_same_array_case(self):
        X = [(1, 1)]
        Y = [(1, 1)]
        expected = (0, [])
        self.assertEqual(update_distance(X, Y), expected)

    def test_multiple_deletion_case(self):
        X = [(1, 1), (2, 2), (3, 3), (4, 4), (5, 5)]
        Y = [(3, 3)]
        expected = (4, ['delete(1)', 'delete(1)', 'delete(2)', 'delete(2)'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_multiple_insertion_case(self):
        X = [(3, 3)]
        Y = [(1, 1), (2, 2), (3, 3), (4, 4), (5, 5)]
        expected = (4, ['insert((1, 1),0)', 'insert((2, 2),1)', 'insert((4, 4),3)', 'insert((5, 5),4)'])
        self.assertEqual(update_distance(X, Y), expected)
    
    def test_replace_case(self):
        X = [(1, 1)]
        Y = [(2, 2)]
        expected = (1, ['replace(1,(2, 2))'])
        self.assertEqual(update_distance(X, Y), expected)
    
    # blackbox testing 
    def test_base_case(self):   
        X = []
        Y = []
        expected = (0, [])
        self.assertEqual(update_distance(X, Y), expected)

    def test_multiple_replace_case(self):
        X = [(1, 1), (3,3)]
        Y = [(2, 2), (4,4)]
        expected = (2, ['replace(1,(2, 2))', 'replace(2,(4, 4))'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_tuple_sum_equal_case(self):
        X = [(1, 3), (1,4)]
        Y = [(2, 2), (2,3)]
        expected = (2, ['replace(1,(2, 2))', 'replace(2,(2, 3))'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_combined_operations_case(self):
        X = [(1, 1), (2, 2), (3, 3), (6, 6)]
        Y = [(2, 2), (4, 4), (3, 3), (5, 5)]
        expected = (3, ['delete(1)', 'insert((4, 4),1)', 'replace(4,(5, 5))'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_element_shuffling_case(self):
        X = [(1, 1), (2, 2), (3, 3), (4, 4)]
        Y = [(4, 4), (1, 1), (3, 3), (2, 2)]
        expected = (3, ['insert((4, 4),0)', 'delete(3)', 'replace(4,(2, 2))'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_end_replace_case(self):
        X = [(1, 1), (2, 2), (3, 3), (4, 4)]
        Y = [(1, 1), (2, 2), (3, 3), (5, 5)]
        expected = (1, ['replace(4,(5, 5))'])
        self.assertEqual(update_distance(X, Y), expected)
    
    def test_beginning_replace_case(self):
        X = [(1, 1), (2, 2), (3, 3), (4, 4)]
        Y = [(5, 5), (2, 2), (3, 3), (4, 4)]
        expected = (1, ['replace(1,(5, 5))'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_middle_replace_case(self):
        X = [(1, 1), (2, 2), (3, 3)]
        Y = [(1, 1), (5, 5), (3, 3)]
        expected = (1, ['replace(2,(5, 5))'])
        self.assertEqual(update_distance(X, Y), expected)

    def test_multiple_insertion_to_end_case(self):
        X = [(1, 1), (2, 2), (3, 3), (4, 4)]
        Y = [(1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6)]
        expected = (2, ['insert((5, 5),4)', 'insert((6, 6),5)'])
        self.assertEqual(update_distance(X, Y), expected)

if __name__ == '__main__':
    unittest.main()
    # all testcaseses passed